# Exercício Aula 2: Sobrecarga

Olá! Neste exercício estão codificados os exemplos da Aula 2 do curso de Métodos. Além disso também possui algumas explicações a mais.
