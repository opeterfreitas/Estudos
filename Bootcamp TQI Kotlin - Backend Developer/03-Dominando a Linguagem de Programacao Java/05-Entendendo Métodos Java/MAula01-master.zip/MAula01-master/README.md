# Exercício Aula 1: Criação

Olá! Neste exercício estão codificados os exemplos da Aula 1 do curso de Métodos. Além disso também possui algumas explicações a mais.
