# Exercício Aula 3: Retornos

Olá! Neste exercício estão codificados os exemplos da Aula 3 do curso de Métodos. Além disso também possui algumas explicações a mais.
